import { createContext, useContext, useState, ReactNode } from 'react';
import { User, Lead, UserRole } from '../types';
import { mockCurrentUser, mockLeads, mockSalesPartners, mockServicePartners } from '../data/mockData';

interface AppContextType {
  currentUser: User;
  setCurrentUser: (u: User) => void;
  leads: Lead[];
  setLeads: (l: Lead[]) => void;
  addLead: (l: Lead) => void;
  updateLead: (l: Lead) => void;
  activeRole: UserRole;
  setActiveRole: (r: UserRole) => void;
}

const AppContext = createContext<AppContextType>(null!);

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User>(mockCurrentUser);
  const [leads, setLeads] = useState<Lead[]>(mockLeads);
  const [activeRole, setActiveRole] = useState<UserRole>('admin');

  const addLead = (lead: Lead) => setLeads(prev => [lead, ...prev]);
  const updateLead = (updated: Lead) =>
    setLeads(prev => prev.map(l => l.id === updated.id ? updated : l));

  return (
    <AppContext.Provider value={{ currentUser, setCurrentUser, leads, setLeads, addLead, updateLead, activeRole, setActiveRole }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
